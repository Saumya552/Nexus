/**
 * API endpoints and HTTP request methods
 */
const API_BASE = 'backend';

const api = {
    /**
     * Helper to perform fetch requests
     */
    async request(endpoint, options = {}) {
        const url = `${API_BASE}/${endpoint}`;
        
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        };

        const fetchOptions = { ...defaultOptions, ...options };
        
        try {
            const response = await fetch(url, fetchOptions);
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'API request failed');
            }
            
            return data;
        } catch (error) {
            console.error(`API Error (${endpoint}):`, error);
            throw error;
        }
    },

    /**
     * Auth API
     */
    auth: {
        login: async (username, password) => {
            return await api.request('auth.php?action=login', {
                method: 'POST',
                body: JSON.stringify({ username, password })
            });
        },
        
        logout: async () => {
            return await api.request('auth.php?action=logout', {
                method: 'POST'
            });
        },
        
        check: async () => {
            return await api.request('auth.php?action=check', {
                method: 'GET'
            });
        },

        register: async (username, email, password) => {
            return await api.request('auth.php?action=register', {
                method: 'POST',
                body: JSON.stringify({ username, email, password })
            });
        }
    },

    /**
     * Dashboard API
     */
    dashboard: {
        getSummary: async () => {
            return await api.request('dashboard.php?action=summary', {
                method: 'GET'
            });
        }
    },

    /**
     * Predictions API
     */
    predictions: {
        getSolar: async (location = null) => {
            let url = 'predictions.php?action=solar';
            if (location) url += `&location=${encodeURIComponent(location)}`;
            return await api.request(url, { method: 'GET' });
        },
        
        getWind: async (location = null) => {
            let url = 'predictions.php?action=wind';
            if (location) url += `&location=${encodeURIComponent(location)}`;
            return await api.request(url, { method: 'GET' });
        }
    },

    /**
     * Contact API
     */
    contact: {
        submit: async (data) => {
            return await api.request('contact.php?action=submit', {
                method: 'POST',
                body: JSON.stringify(data)
            });
        }
    },

    /**
     * Admin API
     */
    admin: {
        getMessages: async () => {
            return await api.request('admin.php?action=messages', { method: 'GET' });
        },
        markMessageRead: async (id) => {
            return await api.request('admin.php?action=mark_read', {
                method: 'POST',
                body: JSON.stringify({ id })
            });
        },
        getUsers: async () => {
            return await api.request('admin.php?action=users', { method: 'GET' });
        }
    },

    /**
     * Climate Analytics API
     */
    climate: {
        getSummary: async () => api.request('climate.php?action=summary', { method: 'GET' }),
        getRegions: async () => api.request('climate.php?action=regions', { method: 'GET' }),
        getHistory: async (region = 'Global Avg') =>
            api.request(`climate.php?action=history&region=${encodeURIComponent(region)}`, { method: 'GET' })
    },

    /**
     * Live Weather API
     */
    weather: {
        getCurrent: async (city = 'Mumbai') =>
            api.request(`weather.php?action=current&city=${encodeURIComponent(city)}`, { method: 'GET' }),
        getForecast: async (city = 'Mumbai') =>
            api.request(`weather.php?action=forecast&city=${encodeURIComponent(city)}`, { method: 'GET' })
    },

    /**
     * User Management API (Admin only)
     */
    userManagement: {
        list:         async ()     => api.request('user_management.php?action=list',   { method: 'GET' }),
        create:       async (data) => api.request('user_management.php?action=create', { method: 'POST', body: JSON.stringify(data) }),
        update:       async (data) => api.request('user_management.php?action=update', { method: 'POST', body: JSON.stringify(data) }),
        remove:       async (id)   => api.request('user_management.php?action=delete', { method: 'POST', body: JSON.stringify({ id }) }),
        toggleStatus: async (id, status) => api.request('user_management.php?action=toggle', { method: 'POST', body: JSON.stringify({ id, status }) }),
        getLogs:      async ()     => api.request('user_management.php?action=logs',   { method: 'GET' })
    }
};


<?php
/**
 * User Management API (Admin only)
 */
require_once '../config/database.php';

// Auth guard — must be admin
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    jsonResponse(['error' => 'Unauthorized'], 403);
}

$action = $_GET['action'] ?? 'list';
$body   = getRequestBody();

switch ($action) {
    case 'list':   listUsers();     break;
    case 'create': createUser($body); break;
    case 'update': updateUser($body); break;
    case 'delete': deleteUser($body); break;
    case 'toggle': toggleStatus($body); break;
    case 'logs':   getActivityLogs(); break;
    default:       jsonResponse(['error' => 'Invalid action'], 400);
}

function listUsers() {
    $db = getDB();
    $stmt = $db->prepare("SELECT id, username, email, role, status, last_login, created_at FROM users ORDER BY created_at DESC");
    $stmt->execute();
    $users = $stmt->fetchAll();

    // Counts
    $total   = count($users);
    $active  = count(array_filter($users, fn($u) => $u['status'] === 'active'));
    $admins  = count(array_filter($users, fn($u) => $u['role'] === 'admin'));

    jsonResponse(['users' => $users, 'stats' => ['total' => $total, 'active' => $active, 'admins' => $admins]]);
}

function createUser($body) {
    $db = getDB();

    $username = trim($body['username'] ?? '');
    $email    = trim($body['email']    ?? '');
    $password = trim($body['password'] ?? '');
    $role     = $body['role'] ?? 'user';

    if (!$username || !$email || !$password) {
        jsonResponse(['error' => 'All fields are required'], 400);
    }

    $hash = password_hash($password, PASSWORD_BCRYPT);

    try {
        $stmt = $db->prepare("INSERT INTO users (username, email, password_hash, role, status) VALUES (?, ?, ?, ?, 'active')");
        $stmt->execute([$username, $email, $hash, $role]);
        $id = $db->lastInsertId();

        logActivity($_SESSION['user_id'], $_SESSION['username'], "Created user: $username");
        jsonResponse(['success' => true, 'id' => $id, 'message' => "User $username created"]);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Username or email already exists'], 409);
    }
}

function updateUser($body) {
    $db = getDB();

    $id    = (int)($body['id'] ?? 0);
    $email = trim($body['email'] ?? '');
    $role  = $body['role'] ?? 'user';

    if (!$id) jsonResponse(['error' => 'User ID required'], 400);

    // Update password only if provided
    if (!empty($body['password'])) {
        $hash = password_hash($body['password'], PASSWORD_BCRYPT);
        $stmt = $db->prepare("UPDATE users SET email=?, role=?, password_hash=? WHERE id=?");
        $stmt->execute([$email, $role, $hash, $id]);
    } else {
        $stmt = $db->prepare("UPDATE users SET email=?, role=? WHERE id=?");
        $stmt->execute([$email, $role, $id]);
    }

    logActivity($_SESSION['user_id'], $_SESSION['username'], "Updated user ID: $id");
    jsonResponse(['success' => true, 'message' => 'User updated']);
}

function deleteUser($body) {
    $db = getDB();
    $id = (int)($body['id'] ?? 0);

    if (!$id) jsonResponse(['error' => 'User ID required'], 400);
    if ($id === $_SESSION['user_id']) jsonResponse(['error' => 'Cannot delete yourself'], 400);

    // Fetch username before deleting
    $stmt = $db->prepare("SELECT username FROM users WHERE id=?");
    $stmt->execute([$id]);
    $user = $stmt->fetch();

    $stmt = $db->prepare("DELETE FROM users WHERE id=?");
    $stmt->execute([$id]);

    logActivity($_SESSION['user_id'], $_SESSION['username'], "Deleted user: " . ($user['username'] ?? $id));
    jsonResponse(['success' => true, 'message' => 'User deleted']);
}

function toggleStatus($body) {
    $db = getDB();
    $id     = (int)($body['id'] ?? 0);
    $status = $body['status'] ?? 'active';

    if (!in_array($status, ['active', 'suspended', 'offline'])) {
        jsonResponse(['error' => 'Invalid status'], 400);
    }

    $stmt = $db->prepare("UPDATE users SET status=? WHERE id=?");
    $stmt->execute([$status, $id]);

    logActivity($_SESSION['user_id'], $_SESSION['username'], "Set user $id status to $status");
    jsonResponse(['success' => true]);
}

function getActivityLogs() {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM user_activity_log ORDER BY logged_at DESC LIMIT 50");
    $stmt->execute();
    jsonResponse($stmt->fetchAll());
}

function logActivity($userId, $username, $action) {
    try {
        $db = getDB();
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);
        $stmt = $db->prepare("INSERT INTO user_activity_log (user_id, username, action, ip_address, user_agent) VALUES (?,?,?,?,?)");
        $stmt->execute([$userId, $username, $action, $ip, $ua]);
    } catch (Exception $e) { /* Silently fail log errors */ }
}

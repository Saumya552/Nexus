<?php
require_once '../config/database.php';

// Check auth
if (!isset($_SESSION['user_id'])) {
    jsonResponse(['error' => 'Unauthorized'], 401);
}

$action = $_GET['action'] ?? '';

if ($action === 'summary') {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        jsonResponse(['error' => 'Method not allowed'], 405);
    }

    $db = getDB();

    try {
        // Get counts
        $solarCount = $db->query("SELECT COUNT(*) FROM solar_predictions")->fetchColumn();
        $windCount = $db->query("SELECT COUNT(*) FROM wind_predictions")->fetchColumn();
        $weatherCount = $db->query("SELECT COUNT(*) FROM weather_data")->fetchColumn();

        // Recent Solar Predictions (grouped by date or just get latest few)
        $stmtSolar = $db->query("
            SELECT prediction_date, SUM(predicted_energy_kwh) as predicted_energy_kwh, SUM(actual_energy_kwh) as actual_energy_kwh 
            FROM solar_predictions 
            GROUP BY prediction_date 
            ORDER BY prediction_date DESC 
            LIMIT 7
        ");
        $solarData = $stmtSolar->fetchAll();

        // Recent Wind Predictions
        $stmtWind = $db->query("
            SELECT prediction_date, SUM(predicted_energy_kwh) as predicted_energy_kwh, AVG(predicted_wind_speed) as predicted_wind_speed
            FROM wind_predictions 
            GROUP BY prediction_date 
            ORDER BY prediction_date DESC 
            LIMIT 7
        ");
        $windData = $stmtWind->fetchAll();

        jsonResponse([
            'stats' => [
                'solar_count' => number_format($solarCount),
                'wind_count' => number_format($windCount),
                'weather_count' => number_format($weatherCount)
            ],
            'solar' => $solarData,
            'wind' => $windData
        ]);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
    }

} else {
    jsonResponse(['error' => 'Invalid action'], 400);
}

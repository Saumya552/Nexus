<?php
require_once '../config/database.php';

// Check auth
if (!isset($_SESSION['user_id'])) {
    jsonResponse(['error' => 'Unauthorized'], 401);
}

// Ensure the user has the admin role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    jsonResponse(['error' => 'Forbidden: Admins only'], 403);
}

$action = $_GET['action'] ?? '';

if ($action === 'messages') {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        jsonResponse(['error' => 'Method not allowed'], 405);
    }

    $db = getDB();
    try {
        $stmt = $db->query("SELECT id, name, email, subject, message, is_read, created_at FROM contact_messages ORDER BY created_at DESC");
        $messages = $stmt->fetchAll();
        jsonResponse($messages);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Database error'], 500);
    }

} elseif ($action === 'mark_read') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        jsonResponse(['error' => 'Method not allowed'], 405);
    }

    $body = getRequestBody();
    $messageId = $body['id'] ?? null;

    if (!$messageId) {
        jsonResponse(['error' => 'Message ID required'], 400);
    }

    $db = getDB();
    try {
        $stmt = $db->prepare("UPDATE contact_messages SET is_read = 1 WHERE id = ?");
        $stmt->execute([$messageId]);
        jsonResponse(['message' => 'Marked as read successfully']);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Database error'], 500);
    }

} elseif ($action === 'users') {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        jsonResponse(['error' => 'Method not allowed'], 405);
    }

    $db = getDB();
    try {
        // We will fetch from both users and admin tables for a complete view
        $stmtUsers = $db->query("SELECT id, username, email, role, created_at FROM users");
        $users = $stmtUsers->fetchAll();

        $stmtAdmin = $db->query("SELECT id, username, email, 'admin' as role, created_at FROM admin");
        $admins = $stmtAdmin->fetchAll();

        $allUsers = array_merge($users, $admins);
        
        // Sort by created_at desc
        usort($allUsers, function($a, $b) {
            return strtotime($b['created_at']) - strtotime($a['created_at']);
        });

        jsonResponse($allUsers);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Database error'], 500);
    }

} else {
    jsonResponse(['error' => 'Invalid action'], 400);
}

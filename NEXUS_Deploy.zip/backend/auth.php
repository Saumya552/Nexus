<?php
require_once '../config/database.php';

$action = $_GET['action'] ?? '';

if ($action === 'login') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        jsonResponse(['error' => 'Method not allowed'], 405);
    }
    
    $body = getRequestBody();
    $username = $body['username'] ?? '';
    $password = $body['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        jsonResponse(['error' => 'Username and password required'], 400);
    }
    
    $db = getDB();
    
    // Check users table
    $stmt = $db->prepare('SELECT id, username, email, password_hash, role FROM users WHERE username = ?');
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    // Fallback to admin table
    if (!$user) {
        $stmt = $db->prepare('SELECT id, username, email, password_hash FROM admin WHERE username = ?');
        $stmt->execute([$username]);
        $admin = $stmt->fetch();
        if ($admin) {
            $user = $admin;
            $user['role'] = 'admin';
            
            // Update last_login
            $update = $db->prepare('UPDATE admin SET last_login = CURRENT_TIMESTAMP WHERE id = ?');
            $update->execute([$user['id']]);
        }
    }
    
    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['email'] = $user['email'];
        
        // Update last_login on users table
        try {
            $update = $db->prepare('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?');
            $update->execute([$user['id']]);
        } catch (Exception $e) { /* column may not exist yet */ }
        
        // Log login activity
        try {
            $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
            $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);
            $log = $db->prepare('INSERT INTO user_activity_log (user_id, username, action, ip_address, user_agent) VALUES (?,?,?,?,?)');
            $log->execute([$user['id'], $user['username'], 'Logged in', $ip, $ua]);
        } catch (Exception $e) { /* table may not exist yet */ }
        
        jsonResponse([
            'message' => 'Login successful',
            'user' => [
                'id' => $user['id'],
                'username' => $user['username'],
                'role' => $user['role'],
                'email' => $user['email']
            ]
        ]);
    } else {
        jsonResponse(['error' => 'Invalid username or password'], 401);
    }
    
} elseif ($action === 'logout') {
    // Log logout activity before destroying session
    if (isset($_SESSION['user_id'])) {
        try {
            $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
            $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);
            $log = getDB()->prepare('INSERT INTO user_activity_log (user_id, username, action, ip_address, user_agent) VALUES (?,?,?,?,?)');
            $log->execute([$_SESSION['user_id'], $_SESSION['username'], 'Logged out', $ip, $ua]);
        } catch (Exception $e) { /* ignore */ }
    }
    session_destroy();
    jsonResponse(['message' => 'Logged out successfully']);
    
} elseif ($action === 'check') {
    if (isset($_SESSION['user_id'])) {
        jsonResponse([
            'authenticated' => true,
            'user' => [
                'id' => $_SESSION['user_id'],
                'username' => $_SESSION['username'],
                'role' => $_SESSION['role'],
                'email' => $_SESSION['email']
            ]
        ]);
    } else {
        jsonResponse(['authenticated' => false], 401);
    }
    
} elseif ($action === 'register') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        jsonResponse(['error' => 'Method not allowed'], 405);
    }

    $body = getRequestBody();
    $username = trim($body['username'] ?? '');
    $email    = trim($body['email'] ?? '');
    $password = $body['password'] ?? '';

    // Validation
    if (empty($username) || empty($email) || empty($password)) {
        jsonResponse(['error' => 'All fields are required'], 400);
    }
    if (strlen($username) < 3) {
        jsonResponse(['error' => 'Username must be at least 3 characters'], 400);
    }
    if (strlen($password) < 6) {
        jsonResponse(['error' => 'Passcode must be at least 6 characters'], 400);
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(['error' => 'Invalid email format'], 400);
    }

    $db = getDB();

    // Check if username or email already exists
    $stmt = $db->prepare('SELECT id FROM users WHERE username = ? OR email = ?');
    $stmt->execute([$username, $email]);
    if ($stmt->fetch()) {
        jsonResponse(['error' => 'Username or email already registered'], 409);
    }

    $hash = password_hash($password, PASSWORD_BCRYPT);

    $stmt = $db->prepare('INSERT INTO users (username, email, password_hash, role, status) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$username, $email, $hash, 'user', 'active']);
    $id = $db->lastInsertId();

    // Log the registration
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);
        $log = $db->prepare('INSERT INTO user_activity_log (user_id, username, action, ip_address, user_agent) VALUES (?,?,?,?,?)');
        $log->execute([$id, $username, 'Account created', $ip, $ua]);
    } catch (Exception $e) { /* ignore */ }

    jsonResponse(['message' => 'Account created successfully', 'id' => $id]);

} else {
    jsonResponse(['error' => 'Invalid action'], 400);
}

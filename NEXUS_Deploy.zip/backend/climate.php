<?php
/**
 * Climate Analytics API
 */
require_once '../config/database.php';

$action = $_GET['action'] ?? 'summary';

switch ($action) {
    case 'summary':
        getClimateSummary();
        break;
    case 'regions':
        getRegions();
        break;
    case 'history':
        getHistory();
        break;
    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}

function getClimateSummary() {
    $db = getDB();
    
    // Get global avg row
    $stmt = $db->prepare("SELECT * FROM climate_data WHERE region = 'Global Avg' LIMIT 1");
    $stmt->execute();
    $global = $stmt->fetch();

    // Totals across all non-global regions
    $stmt2 = $db->prepare("SELECT 
        SUM(co2_saved_tonnes) as total_co2,
        AVG(green_energy_pct) as avg_green,
        AVG(aqi) as avg_aqi,
        AVG(sustainability_score) as avg_score
        FROM climate_data WHERE region != 'Global Avg'");
    $stmt2->execute();
    $totals = $stmt2->fetch();

    jsonResponse([
        'global' => $global,
        'totals' => [
            'total_co2_saved'     => round($totals['total_co2'], 0),
            'avg_green_energy'    => round($totals['avg_green'], 1),
            'avg_aqi'             => round($totals['avg_aqi'], 0),
            'avg_sustainability'  => round($totals['avg_score'], 0),
        ]
    ]);
}

function getRegions() {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM climate_data WHERE region != 'Global Avg' ORDER BY sustainability_score DESC");
    $stmt->execute();
    jsonResponse($stmt->fetchAll());
}

function getHistory() {
    $db = getDB();
    $region = $_GET['region'] ?? 'Global Avg';
    $stmt = $db->prepare("SELECT * FROM climate_history WHERE region = ? ORDER BY recorded_date ASC LIMIT 14");
    $stmt->execute([$region]);
    jsonResponse($stmt->fetchAll());
}

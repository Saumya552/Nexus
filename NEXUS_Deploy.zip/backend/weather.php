<?php
/**
 * Live Weather API (Demo data mode)
 */
require_once '../config/database.php';

$action = $_GET['action'] ?? 'current';
$city   = $_GET['city'] ?? 'Mumbai';

switch ($action) {
    case 'current':
        getCurrentWeather($city);
        break;
    case 'forecast':
        getForecast($city);
        break;
    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}

function getCurrentWeather($city) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM weather_cache WHERE city = ? LIMIT 1");
    $stmt->execute([$city]);
    $weather = $stmt->fetch();

    if (!$weather) {
        // Default fallback
        jsonResponse(['error' => 'City not found'], 404);
        return;
    }

    // Simulate "live" feel by adding small random deltas
    $weather['temperature']  = round($weather['temperature']  + (rand(-10, 10) / 10), 1);
    $weather['humidity']     = max(10, min(100, $weather['humidity'] + rand(-2, 2)));
    $weather['wind_speed']   = round(max(0, $weather['wind_speed'] + (rand(-5, 5) / 10)), 1);
    $weather['cached_at']    = date('Y-m-d H:i:s');

    jsonResponse($weather);
}

function getForecast($city) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM weather_forecast WHERE city = ? ORDER BY forecast_date ASC LIMIT 7");
    $stmt->execute([$city]);
    jsonResponse($stmt->fetchAll());
}

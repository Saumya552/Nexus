<?php
require_once '../config/database.php';

// Check auth
if (!isset($_SESSION['user_id'])) {
    jsonResponse(['error' => 'Unauthorized'], 401);
}

$action = $_GET['action'] ?? '';
$location = $_GET['location'] ?? null;

if ($action === 'solar') {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        jsonResponse(['error' => 'Method not allowed'], 405);
    }

    $db = getDB();
    try {
        $sql = "SELECT * FROM solar_predictions";
        $params = [];

        if (!empty($location)) {
            $sql .= " WHERE location = ?";
            $params[] = $location;
        }

        $sql .= " ORDER BY prediction_date DESC LIMIT 30"; // Last 30 records
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $data = $stmt->fetchAll();
        
        jsonResponse($data);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Database error'], 500);
    }

} elseif ($action === 'wind') {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        jsonResponse(['error' => 'Method not allowed'], 405);
    }

    $db = getDB();
    try {
        $sql = "SELECT * FROM wind_predictions";
        $params = [];

        if (!empty($location)) {
            $sql .= " WHERE location = ?";
            $params[] = $location;
        }

        $sql .= " ORDER BY prediction_date DESC LIMIT 30"; // Last 30 records
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $data = $stmt->fetchAll();
        
        jsonResponse($data);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Database error'], 500);
    }

} else {
    jsonResponse(['error' => 'Invalid action'], 400);
}

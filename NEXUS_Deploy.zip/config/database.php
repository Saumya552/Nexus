<?php
// ======================================================
// DEPLOYMENT CONFIG — Update these for InfinityFree
// ======================================================
// After creating your MySQL database on InfinityFree,
// replace the values below with your actual credentials.
// Find them in: InfinityFree Panel > MySQL Databases
// ======================================================

if ($_SERVER['HTTP_HOST'] !== 'localhost') {
    // ---- PRODUCTION (InfinityFree) ----
    define('DB_HOST', 'sql306.infinityfree.com');   // <-- Your MySQL hostname
    define('DB_NAME', 'if0_XXXXXXX_nexus');          // <-- Your database name
    define('DB_USER', 'if0_XXXXXXX');                // <-- Your MySQL username
    define('DB_PASS', 'YOUR_DB_PASSWORD');            // <-- Your MySQL password
} else {
    // ---- LOCAL (XAMPP) ----
    define('DB_HOST', 'localhost');
    define('DB_NAME', 'energy_prediction');
    define('DB_USER', 'root');
    define('DB_PASS', '');
}

/**
 * Get PDO database connection
 * @return PDO
 */
function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]);
            exit;
        }
    }
    return $pdo;
}

/**
 * Send JSON response
 */
function jsonResponse($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    echo json_encode($data);
    exit;
}

/**
 * Get JSON request body
 */
function getRequestBody() {
    $body = file_get_contents('php://input');
    return json_decode($body, true) ?: [];
}

// Handle preflight OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    http_response_code(204);
    exit;
}

// Start session for auth
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

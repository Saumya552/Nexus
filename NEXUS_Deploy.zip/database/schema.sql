-- =====================================================
-- Wind and Solar Energy Prediction System
-- Database Schema + Seed Data
-- =====================================================
-- Run this in phpMyAdmin or MySQL CLI after creating
-- the database: CREATE DATABASE energy_prediction;
-- =====================================================

CREATE DATABASE IF NOT EXISTS energy_prediction;
USE energy_prediction;

-- ---------------------------------------------------
-- 1. USERS TABLE
-- ---------------------------------------------------
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------
-- 2. ADMIN TABLE
-- ---------------------------------------------------
DROP TABLE IF EXISTS admin;
CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL,
    last_login TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------
-- 3. WEATHER DATA TABLE
-- ---------------------------------------------------
DROP TABLE IF EXISTS weather_data;
CREATE TABLE weather_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    location VARCHAR(100) NOT NULL,
    temperature DECIMAL(5,2),
    humidity DECIMAL(5,2),
    wind_speed DECIMAL(6,2),
    wind_direction VARCHAR(10),
    pressure DECIMAL(7,2),
    cloud_cover DECIMAL(5,2),
    uv_index DECIMAL(4,2),
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_location (location),
    INDEX idx_recorded (recorded_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------
-- 4. SOLAR PREDICTIONS TABLE
-- ---------------------------------------------------
DROP TABLE IF EXISTS solar_predictions;
CREATE TABLE solar_predictions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    location VARCHAR(100) NOT NULL,
    prediction_date DATE NOT NULL,
    predicted_radiation DECIMAL(8,2) COMMENT 'W/m²',
    predicted_energy_kwh DECIMAL(10,2),
    actual_energy_kwh DECIMAL(10,2) DEFAULT NULL,
    panel_efficiency DECIMAL(5,2) DEFAULT 18.50,
    confidence DECIMAL(5,2) DEFAULT 85.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_location (location),
    INDEX idx_date (prediction_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------
-- 5. WIND PREDICTIONS TABLE
-- ---------------------------------------------------
DROP TABLE IF EXISTS wind_predictions;
CREATE TABLE wind_predictions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    location VARCHAR(100) NOT NULL,
    prediction_date DATE NOT NULL,
    predicted_wind_speed DECIMAL(6,2) COMMENT 'm/s',
    predicted_energy_kwh DECIMAL(10,2),
    actual_energy_kwh DECIMAL(10,2) DEFAULT NULL,
    turbine_capacity DECIMAL(8,2) DEFAULT 2500.00 COMMENT 'kW',
    confidence DECIMAL(5,2) DEFAULT 82.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_location (location),
    INDEX idx_date (prediction_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------
-- 6. CONTACT MESSAGES TABLE
-- ---------------------------------------------------
DROP TABLE IF EXISTS contact_messages;
CREATE TABLE contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    subject VARCHAR(200),
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- =====================================================
-- SEED DATA
-- =====================================================

-- Admin account (password: admin123)
INSERT INTO admin (username, password_hash, email) VALUES
('admin', '$2y$10$CQhV1aepvZXjA4Py5hOET.qYDIWdWPniKA1.1bwiXQ/rXFFhUzJDe', 'admin@energypredict.com');

-- Users (password for all: password123)
INSERT INTO users (username, email, password_hash, role) VALUES
('john_doe', 'john@example.com', '$2y$10$SxS7oUl8A0kdDI6BYGkWa.ey6bJvX3K3NQYvLrnaK8dewKPWIJAzS', 'user'),
('jane_smith', 'jane@example.com', '$2y$10$SxS7oUl8A0kdDI6BYGkWa.ey6bJvX3K3NQYvLrnaK8dewKPWIJAzS', 'user'),
('alex_green', 'alex@example.com', '$2y$10$SxS7oUl8A0kdDI6BYGkWa.ey6bJvX3K3NQYvLrnaK8dewKPWIJAzS', 'user'),
('sarah_wind', 'sarah@example.com', '$2y$10$SxS7oUl8A0kdDI6BYGkWa.ey6bJvX3K3NQYvLrnaK8dewKPWIJAzS', 'admin'),
('mike_solar', 'mike@example.com', '$2y$10$SxS7oUl8A0kdDI6BYGkWa.ey6bJvX3K3NQYvLrnaK8dewKPWIJAzS', 'user');

-- Weather Data (35 records across 5 locations over recent dates)
INSERT INTO weather_data (location, temperature, humidity, wind_speed, wind_direction, pressure, cloud_cover, uv_index, recorded_at) VALUES
('Mumbai', 32.50, 78.00, 12.30, 'SW', 1008.50, 45.00, 8.50, '2026-05-01 08:00:00'),
('Mumbai', 33.10, 75.00, 11.80, 'SW', 1009.20, 40.00, 9.00, '2026-05-02 08:00:00'),
('Mumbai', 31.80, 80.00, 13.50, 'W', 1007.80, 55.00, 7.50, '2026-05-03 08:00:00'),
('Mumbai', 34.20, 72.00, 10.20, 'SW', 1010.10, 30.00, 9.50, '2026-05-04 08:00:00'),
('Mumbai', 33.50, 76.00, 14.10, 'W', 1008.00, 50.00, 8.00, '2026-05-05 08:00:00'),
('Mumbai', 32.00, 82.00, 15.20, 'SW', 1006.50, 60.00, 7.00, '2026-05-06 08:00:00'),
('Mumbai', 33.80, 74.00, 11.00, 'S', 1009.80, 35.00, 9.20, '2026-05-07 08:00:00'),
('Delhi', 38.50, 45.00, 8.50, 'NW', 1005.30, 20.00, 10.00, '2026-05-01 08:00:00'),
('Delhi', 39.20, 42.00, 9.10, 'N', 1004.80, 15.00, 10.50, '2026-05-02 08:00:00'),
('Delhi', 37.80, 48.00, 7.80, 'NW', 1006.00, 25.00, 9.80, '2026-05-03 08:00:00'),
('Delhi', 40.10, 40.00, 10.50, 'W', 1004.20, 10.00, 11.00, '2026-05-04 08:00:00'),
('Delhi', 38.00, 50.00, 8.00, 'NW', 1005.50, 30.00, 9.50, '2026-05-05 08:00:00'),
('Delhi', 39.50, 43.00, 9.80, 'N', 1004.50, 18.00, 10.20, '2026-05-06 08:00:00'),
('Delhi', 37.00, 52.00, 7.20, 'NE', 1006.80, 35.00, 9.00, '2026-05-07 08:00:00'),
('Bangalore', 28.50, 65.00, 6.50, 'E', 1012.00, 50.00, 7.50, '2026-05-01 08:00:00'),
('Bangalore', 27.80, 68.00, 5.80, 'SE', 1012.50, 55.00, 7.00, '2026-05-02 08:00:00'),
('Bangalore', 29.20, 62.00, 7.20, 'E', 1011.80, 45.00, 8.00, '2026-05-03 08:00:00'),
('Bangalore', 28.00, 70.00, 6.00, 'SE', 1013.00, 60.00, 6.50, '2026-05-04 08:00:00'),
('Bangalore', 29.50, 60.00, 7.80, 'E', 1011.50, 40.00, 8.50, '2026-05-05 08:00:00'),
('Bangalore', 27.50, 72.00, 5.50, 'S', 1013.20, 65.00, 6.00, '2026-05-06 08:00:00'),
('Bangalore', 28.80, 64.00, 6.80, 'SE', 1012.20, 48.00, 7.80, '2026-05-07 08:00:00'),
('Chennai', 35.00, 70.00, 15.50, 'SE', 1009.00, 35.00, 9.00, '2026-05-01 08:00:00'),
('Chennai', 35.80, 68.00, 16.20, 'S', 1008.50, 30.00, 9.50, '2026-05-02 08:00:00'),
('Chennai', 34.50, 73.00, 14.80, 'SE', 1009.50, 40.00, 8.50, '2026-05-03 08:00:00'),
('Chennai', 36.20, 65.00, 17.00, 'S', 1008.00, 25.00, 10.00, '2026-05-04 08:00:00'),
('Chennai', 35.50, 71.00, 15.00, 'SE', 1009.20, 38.00, 8.80, '2026-05-05 08:00:00'),
('Chennai', 34.80, 74.00, 16.50, 'S', 1008.20, 42.00, 8.20, '2026-05-06 08:00:00'),
('Chennai', 36.00, 66.00, 14.50, 'SE', 1009.80, 28.00, 9.80, '2026-05-07 08:00:00'),
('Jaipur', 40.00, 30.00, 9.00, 'W', 1003.50, 10.00, 11.50, '2026-05-01 08:00:00'),
('Jaipur', 41.20, 28.00, 10.20, 'NW', 1003.00, 8.00, 12.00, '2026-05-02 08:00:00'),
('Jaipur', 39.50, 32.00, 8.50, 'W', 1004.00, 12.00, 11.00, '2026-05-03 08:00:00'),
('Jaipur', 42.00, 25.00, 11.00, 'NW', 1002.50, 5.00, 12.50, '2026-05-04 08:00:00'),
('Jaipur', 40.50, 30.00, 9.50, 'W', 1003.20, 10.00, 11.80, '2026-05-05 08:00:00'),
('Jaipur', 39.00, 35.00, 8.00, 'SW', 1004.50, 15.00, 10.50, '2026-05-06 08:00:00'),
('Jaipur', 41.50, 27.00, 10.80, 'NW', 1002.80, 7.00, 12.20, '2026-05-07 08:00:00');

-- Solar Predictions (35 records)
INSERT INTO solar_predictions (location, prediction_date, predicted_radiation, predicted_energy_kwh, actual_energy_kwh, panel_efficiency, confidence) VALUES
('Mumbai', '2026-05-01', 850.00, 425.00, 418.50, 18.50, 87.00),
('Mumbai', '2026-05-02', 880.00, 440.00, 435.20, 18.50, 89.00),
('Mumbai', '2026-05-03', 720.00, 360.00, 345.00, 18.00, 82.00),
('Mumbai', '2026-05-04', 920.00, 460.00, 455.80, 19.00, 91.00),
('Mumbai', '2026-05-05', 800.00, 400.00, 392.00, 18.50, 85.00),
('Mumbai', '2026-05-06', 680.00, 340.00, 328.50, 17.50, 80.00),
('Mumbai', '2026-05-07', 900.00, 450.00, 445.00, 19.00, 90.00),
('Delhi', '2026-05-01', 950.00, 475.00, 470.00, 19.50, 92.00),
('Delhi', '2026-05-02', 980.00, 490.00, 485.50, 20.00, 94.00),
('Delhi', '2026-05-03', 900.00, 450.00, 442.00, 19.00, 88.00),
('Delhi', '2026-05-04', 1020.00, 510.00, 505.00, 20.50, 95.00),
('Delhi', '2026-05-05', 880.00, 440.00, 430.00, 18.50, 86.00),
('Delhi', '2026-05-06', 960.00, 480.00, 475.00, 20.00, 93.00),
('Delhi', '2026-05-07', 850.00, 425.00, 418.00, 18.50, 87.00),
('Bangalore', '2026-05-01', 750.00, 375.00, 368.00, 17.50, 84.00),
('Bangalore', '2026-05-02', 720.00, 360.00, 352.00, 17.00, 82.00),
('Bangalore', '2026-05-03', 800.00, 400.00, 395.00, 18.00, 86.00),
('Bangalore', '2026-05-04', 680.00, 340.00, 330.00, 16.50, 80.00),
('Bangalore', '2026-05-05', 820.00, 410.00, 405.00, 18.50, 88.00),
('Bangalore', '2026-05-06', 650.00, 325.00, 315.00, 16.00, 78.00),
('Bangalore', '2026-05-07', 780.00, 390.00, 385.00, 17.50, 85.00),
('Chennai', '2026-05-01', 900.00, 450.00, 445.00, 19.00, 90.00),
('Chennai', '2026-05-02', 920.00, 460.00, 455.00, 19.50, 91.00),
('Chennai', '2026-05-03', 850.00, 425.00, 418.00, 18.50, 87.00),
('Chennai', '2026-05-04', 960.00, 480.00, 475.00, 20.00, 93.00),
('Chennai', '2026-05-05', 880.00, 440.00, 435.00, 18.50, 89.00),
('Chennai', '2026-05-06', 820.00, 410.00, 402.00, 18.00, 86.00),
('Chennai', '2026-05-07', 940.00, 470.00, 465.00, 19.50, 92.00),
('Jaipur', '2026-05-01', 1050.00, 525.00, 520.00, 21.00, 96.00),
('Jaipur', '2026-05-02', 1080.00, 540.00, 535.00, 21.50, 97.00),
('Jaipur', '2026-05-03', 1000.00, 500.00, 492.00, 20.50, 94.00),
('Jaipur', '2026-05-04', 1100.00, 550.00, 545.00, 22.00, 98.00),
('Jaipur', '2026-05-05', 1020.00, 510.00, 505.00, 21.00, 95.00),
('Jaipur', '2026-05-06', 980.00, 490.00, 482.00, 20.00, 93.00),
('Jaipur', '2026-05-07', 1060.00, 530.00, 525.00, 21.50, 96.00);

-- Wind Predictions (35 records)
INSERT INTO wind_predictions (location, prediction_date, predicted_wind_speed, predicted_energy_kwh, actual_energy_kwh, turbine_capacity, confidence) VALUES
('Mumbai', '2026-05-01', 12.30, 1850.00, 1820.00, 2500.00, 85.00),
('Mumbai', '2026-05-02', 11.80, 1750.00, 1720.00, 2500.00, 83.00),
('Mumbai', '2026-05-03', 13.50, 2020.00, 1980.00, 2500.00, 87.00),
('Mumbai', '2026-05-04', 10.20, 1530.00, 1500.00, 2500.00, 80.00),
('Mumbai', '2026-05-05', 14.10, 2115.00, 2080.00, 3000.00, 88.00),
('Mumbai', '2026-05-06', 15.20, 2280.00, 2250.00, 3000.00, 90.00),
('Mumbai', '2026-05-07', 11.00, 1650.00, 1620.00, 2500.00, 82.00),
('Delhi', '2026-05-01', 8.50, 1275.00, 1250.00, 2000.00, 78.00),
('Delhi', '2026-05-02', 9.10, 1365.00, 1340.00, 2000.00, 80.00),
('Delhi', '2026-05-03', 7.80, 1170.00, 1140.00, 2000.00, 76.00),
('Delhi', '2026-05-04', 10.50, 1575.00, 1550.00, 2500.00, 83.00),
('Delhi', '2026-05-05', 8.00, 1200.00, 1175.00, 2000.00, 77.00),
('Delhi', '2026-05-06', 9.80, 1470.00, 1445.00, 2000.00, 81.00),
('Delhi', '2026-05-07', 7.20, 1080.00, 1050.00, 2000.00, 74.00),
('Bangalore', '2026-05-01', 6.50, 975.00, 950.00, 1500.00, 72.00),
('Bangalore', '2026-05-02', 5.80, 870.00, 845.00, 1500.00, 70.00),
('Bangalore', '2026-05-03', 7.20, 1080.00, 1060.00, 1500.00, 75.00),
('Bangalore', '2026-05-04', 6.00, 900.00, 875.00, 1500.00, 71.00),
('Bangalore', '2026-05-05', 7.80, 1170.00, 1150.00, 2000.00, 76.00),
('Bangalore', '2026-05-06', 5.50, 825.00, 800.00, 1500.00, 68.00),
('Bangalore', '2026-05-07', 6.80, 1020.00, 1000.00, 1500.00, 73.00),
('Chennai', '2026-05-01', 15.50, 2325.00, 2300.00, 3000.00, 90.00),
('Chennai', '2026-05-02', 16.20, 2430.00, 2400.00, 3000.00, 92.00),
('Chennai', '2026-05-03', 14.80, 2220.00, 2190.00, 3000.00, 88.00),
('Chennai', '2026-05-04', 17.00, 2550.00, 2520.00, 3500.00, 93.00),
('Chennai', '2026-05-05', 15.00, 2250.00, 2220.00, 3000.00, 89.00),
('Chennai', '2026-05-06', 16.50, 2475.00, 2450.00, 3000.00, 91.00),
('Chennai', '2026-05-07', 14.50, 2175.00, 2150.00, 3000.00, 87.00),
('Jaipur', '2026-05-01', 9.00, 1350.00, 1325.00, 2000.00, 79.00),
('Jaipur', '2026-05-02', 10.20, 1530.00, 1505.00, 2500.00, 82.00),
('Jaipur', '2026-05-03', 8.50, 1275.00, 1250.00, 2000.00, 78.00),
('Jaipur', '2026-05-04', 11.00, 1650.00, 1625.00, 2500.00, 84.00),
('Jaipur', '2026-05-05', 9.50, 1425.00, 1400.00, 2000.00, 80.00),
('Jaipur', '2026-05-06', 8.00, 1200.00, 1175.00, 2000.00, 77.00),
('Jaipur', '2026-05-07', 10.80, 1620.00, 1595.00, 2500.00, 83.00);

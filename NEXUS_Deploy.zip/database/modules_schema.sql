-- =====================================================
-- NEXUS Module Extensions: Climate, Weather, User Mgmt
-- Run in phpMyAdmin AFTER the main schema.sql
-- =====================================================
USE energy_prediction;

-- ---------------------------------------------------
-- CLIMATE DATA TABLE
-- ---------------------------------------------------
CREATE TABLE IF NOT EXISTS climate_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    region VARCHAR(100) NOT NULL,
    co2_saved_tonnes DECIMAL(10,2) NOT NULL DEFAULT 0,
    green_energy_pct DECIMAL(5,2) NOT NULL DEFAULT 0,
    aqi INT NOT NULL DEFAULT 50,
    temp_anomaly DECIMAL(4,2) NOT NULL DEFAULT 0,
    sustainability_score INT NOT NULL DEFAULT 0,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------
-- CLIMATE HISTORY (for line charts)
-- ---------------------------------------------------
CREATE TABLE IF NOT EXISTS climate_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    region VARCHAR(100) NOT NULL,
    co2_saved_tonnes DECIMAL(10,2) NOT NULL,
    temp_anomaly DECIMAL(4,2) NOT NULL,
    aqi INT NOT NULL,
    recorded_date DATE NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------
-- WEATHER CACHE TABLE
-- ---------------------------------------------------
CREATE TABLE IF NOT EXISTS weather_cache (
    id INT AUTO_INCREMENT PRIMARY KEY,
    city VARCHAR(100) NOT NULL,
    temperature DECIMAL(5,2) NOT NULL,
    feels_like DECIMAL(5,2) NOT NULL,
    humidity INT NOT NULL,
    pressure INT NOT NULL,
    wind_speed DECIMAL(5,2) NOT NULL,
    wind_direction VARCHAR(10) NOT NULL DEFAULT 'N',
    uv_index DECIMAL(3,1) NOT NULL DEFAULT 0,
    cloud_pct INT NOT NULL DEFAULT 0,
    condition_text VARCHAR(100) NOT NULL DEFAULT 'Clear',
    rain_probability INT NOT NULL DEFAULT 0,
    solar_efficiency_pct INT NOT NULL DEFAULT 80,
    cached_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------
-- WEATHER FORECAST (7-day)
-- ---------------------------------------------------
CREATE TABLE IF NOT EXISTS weather_forecast (
    id INT AUTO_INCREMENT PRIMARY KEY,
    city VARCHAR(100) NOT NULL,
    forecast_date DATE NOT NULL,
    temp_high DECIMAL(5,2) NOT NULL,
    temp_low DECIMAL(5,2) NOT NULL,
    condition_text VARCHAR(100) NOT NULL,
    rain_probability INT NOT NULL DEFAULT 0,
    wind_speed DECIMAL(5,2) NOT NULL,
    solar_efficiency_pct INT NOT NULL DEFAULT 80,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------
-- USER ACTIVITY LOG
-- ---------------------------------------------------
CREATE TABLE IF NOT EXISTS user_activity_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    username VARCHAR(50) NOT NULL,
    action VARCHAR(100) NOT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    user_agent VARCHAR(255) DEFAULT NULL,
    logged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Extend users table with new columns if not exists
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS role_extended ENUM('admin','operator','analyst','user') DEFAULT 'user',
    ADD COLUMN IF NOT EXISTS status ENUM('active','offline','suspended') DEFAULT 'active',
    ADD COLUMN IF NOT EXISTS last_login TIMESTAMP NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS avatar_initials VARCHAR(3) DEFAULT NULL;

-- =====================================================
-- SEED DATA
-- =====================================================

-- Climate current data (one row per region)
INSERT IGNORE INTO climate_data (region, co2_saved_tonnes, green_energy_pct, aqi, temp_anomaly, sustainability_score) VALUES
('Mumbai',      12400.50, 67.3, 82,  1.2, 74),
('Delhi',       8200.00,  45.1, 154, 1.8, 52),
('Bangalore',   15800.75, 78.9, 48,  0.9, 88),
('Chennai',     11200.30, 61.4, 71,  1.4, 70),
('Jaipur',      9800.60,  55.7, 95,  1.6, 63),
('Global Avg',  11480.43, 61.7, 90,  1.4, 69);

-- Climate history (last 14 days for charts)
INSERT IGNORE INTO climate_history (region, co2_saved_tonnes, temp_anomaly, aqi, recorded_date) VALUES
('Global Avg', 10200.00, 1.1, 95,  DATE_SUB(CURDATE(), INTERVAL 13 DAY)),
('Global Avg', 10450.00, 1.2, 90,  DATE_SUB(CURDATE(), INTERVAL 12 DAY)),
('Global Avg', 10800.00, 1.0, 88,  DATE_SUB(CURDATE(), INTERVAL 11 DAY)),
('Global Avg', 11000.00, 1.3, 92,  DATE_SUB(CURDATE(), INTERVAL 10 DAY)),
('Global Avg', 10750.00, 1.2, 85,  DATE_SUB(CURDATE(), INTERVAL 9 DAY)),
('Global Avg', 11200.00, 1.4, 91,  DATE_SUB(CURDATE(), INTERVAL 8 DAY)),
('Global Avg', 11400.00, 1.1, 87,  DATE_SUB(CURDATE(), INTERVAL 7 DAY)),
('Global Avg', 11100.00, 1.5, 93,  DATE_SUB(CURDATE(), INTERVAL 6 DAY)),
('Global Avg', 11600.00, 1.3, 89,  DATE_SUB(CURDATE(), INTERVAL 5 DAY)),
('Global Avg', 11800.00, 1.2, 84,  DATE_SUB(CURDATE(), INTERVAL 4 DAY)),
('Global Avg', 11950.00, 1.4, 90,  DATE_SUB(CURDATE(), INTERVAL 3 DAY)),
('Global Avg', 12100.00, 1.6, 94,  DATE_SUB(CURDATE(), INTERVAL 2 DAY)),
('Global Avg', 12300.00, 1.3, 88,  DATE_SUB(CURDATE(), INTERVAL 1 DAY)),
('Global Avg', 11480.43, 1.4, 90,  CURDATE());

-- Weather current data per city
INSERT INTO weather_cache (city, temperature, feels_like, humidity, pressure, wind_speed, wind_direction, uv_index, cloud_pct, condition_text, rain_probability, solar_efficiency_pct) VALUES
('Mumbai',    32.5, 38.0, 78, 1008, 18.5, 'SW', 7.2, 45, 'Partly Cloudy', 35, 68)
ON DUPLICATE KEY UPDATE temperature=32.5;

INSERT IGNORE INTO weather_cache (city, temperature, feels_like, humidity, pressure, wind_speed, wind_direction, uv_index, cloud_pct, condition_text, rain_probability, solar_efficiency_pct) VALUES
('Delhi',     38.2, 42.0, 35, 1002, 12.0, 'NW', 9.1, 15, 'Sunny', 5,  92),
('Bangalore', 26.8, 28.5, 65, 1015, 14.0, 'SE', 5.8, 55, 'Cloudy', 20, 60),
('Chennai',   33.0, 40.0, 82, 1006, 22.0, 'NE', 6.5, 60, 'Humid & Cloudy', 45, 55),
('Jaipur',    40.1, 44.5, 20, 998,  8.5,  'W',  10.0, 5, 'Blazing Sun', 2,  95);

-- Weather 7-day forecast
DELETE FROM weather_forecast WHERE city IN ('Mumbai','Delhi','Bangalore','Chennai','Jaipur');
INSERT INTO weather_forecast (city, forecast_date, temp_high, temp_low, condition_text, rain_probability, wind_speed, solar_efficiency_pct) VALUES
('Mumbai', CURDATE(),                           33, 27, 'Partly Cloudy', 35, 18, 68),
('Mumbai', DATE_ADD(CURDATE(), INTERVAL 1 DAY), 31, 26, 'Rain Showers',  75, 25, 35),
('Mumbai', DATE_ADD(CURDATE(), INTERVAL 2 DAY), 29, 25, 'Heavy Rain',    90, 30, 20),
('Mumbai', DATE_ADD(CURDATE(), INTERVAL 3 DAY), 30, 26, 'Overcast',      55, 20, 45),
('Mumbai', DATE_ADD(CURDATE(), INTERVAL 4 DAY), 32, 27, 'Partly Cloudy', 30, 16, 65),
('Mumbai', DATE_ADD(CURDATE(), INTERVAL 5 DAY), 33, 27, 'Sunny',          8, 14, 88),
('Mumbai', DATE_ADD(CURDATE(), INTERVAL 6 DAY), 34, 28, 'Sunny',          5, 12, 92),

('Delhi',  CURDATE(),                           38, 28, 'Sunny',           5, 12, 92),
('Delhi',  DATE_ADD(CURDATE(), INTERVAL 1 DAY), 39, 29, 'Sunny',           3, 10, 95),
('Delhi',  DATE_ADD(CURDATE(), INTERVAL 2 DAY), 40, 30, 'Hot & Sunny',     2,  8, 96),
('Delhi',  DATE_ADD(CURDATE(), INTERVAL 3 DAY), 38, 29, 'Hazy',           10, 15, 80),
('Delhi',  DATE_ADD(CURDATE(), INTERVAL 4 DAY), 36, 27, 'Partly Cloudy',  20, 18, 72),
('Delhi',  DATE_ADD(CURDATE(), INTERVAL 5 DAY), 37, 28, 'Sunny',           8, 12, 90),
('Delhi',  DATE_ADD(CURDATE(), INTERVAL 6 DAY), 38, 29, 'Sunny',           4, 10, 93),

('Bangalore', CURDATE(),                           27, 20, 'Cloudy',      20, 14, 60),
('Bangalore', DATE_ADD(CURDATE(), INTERVAL 1 DAY), 25, 18, 'Light Rain',  60, 20, 40),
('Bangalore', DATE_ADD(CURDATE(), INTERVAL 2 DAY), 23, 17, 'Rain',        80, 25, 28),
('Bangalore', DATE_ADD(CURDATE(), INTERVAL 3 DAY), 26, 19, 'Partly Cloudy',35,16, 58),
('Bangalore', DATE_ADD(CURDATE(), INTERVAL 4 DAY), 28, 21, 'Sunny',       10, 12, 85),
('Bangalore', DATE_ADD(CURDATE(), INTERVAL 5 DAY), 27, 20, 'Partly Cloudy',25,14, 68),
('Bangalore', DATE_ADD(CURDATE(), INTERVAL 6 DAY), 26, 19, 'Cloudy',      40, 18, 50),

('Chennai', CURDATE(),                           33, 29, 'Humid & Cloudy', 45, 22, 55),
('Chennai', DATE_ADD(CURDATE(), INTERVAL 1 DAY), 31, 28, 'Rain Showers',   70, 28, 30),
('Chennai', DATE_ADD(CURDATE(), INTERVAL 2 DAY), 30, 27, 'Heavy Rain',     85, 35, 18),
('Chennai', DATE_ADD(CURDATE(), INTERVAL 3 DAY), 32, 28, 'Cloudy',         50, 24, 45),
('Chennai', DATE_ADD(CURDATE(), INTERVAL 4 DAY), 33, 29, 'Partly Cloudy',  30, 20, 62),
('Chennai', DATE_ADD(CURDATE(), INTERVAL 5 DAY), 34, 30, 'Sunny',          10, 18, 82),
('Chennai', DATE_ADD(CURDATE(), INTERVAL 6 DAY), 34, 30, 'Sunny',           8, 16, 85),

('Jaipur', CURDATE(),                           40, 30, 'Blazing Sun',   2,  8, 95),
('Jaipur', DATE_ADD(CURDATE(), INTERVAL 1 DAY), 41, 31, 'Sunny',         1,  7, 97),
('Jaipur', DATE_ADD(CURDATE(), INTERVAL 2 DAY), 42, 32, 'Hot & Sunny',   1,  6, 98),
('Jaipur', DATE_ADD(CURDATE(), INTERVAL 3 DAY), 40, 30, 'Sunny',         3,  9, 95),
('Jaipur', DATE_ADD(CURDATE(), INTERVAL 4 DAY), 39, 29, 'Partly Cloudy', 10, 12, 85),
('Jaipur', DATE_ADD(CURDATE(), INTERVAL 5 DAY), 41, 31, 'Sunny',          2,  8, 96),
('Jaipur', DATE_ADD(CURDATE(), INTERVAL 6 DAY), 40, 30, 'Sunny',          3,  9, 94);

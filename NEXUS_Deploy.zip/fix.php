<?php
require_once 'config/database.php';

try {
    $db = getDB();

    // Create the correct hashes
    $passUser = password_hash('password123', PASSWORD_DEFAULT);
    $passAdmin = password_hash('admin123', PASSWORD_DEFAULT);

    // Update users
    $stmt1 = $db->prepare("UPDATE users SET password_hash = ?");
    $stmt1->execute([$passUser]);

    // Update admin
    $stmt2 = $db->prepare("UPDATE admin SET password_hash = ?");
    $stmt2->execute([$passAdmin]);

    echo "<div style='font-family: sans-serif; padding: 40px; text-align: center;'>";
    echo "<h2 style='color: #10b981;'>✅ Passwords Fixed Successfully!</h2>";
    echo "<p>The database has been updated with the correct password hashes.</p>";
    echo "<p>You can now go back and log in with:</p>";
    echo "<b>Username:</b> john_doe <br> <b>Password:</b> password123";
    echo "<br><br><a href='index.html' style='display: inline-block; padding: 10px 20px; background: #3b82f6; color: white; text-decoration: none; border-radius: 5px;'>Go back to Login</a>";
    echo "</div>";

} catch (PDOException $e) {
    echo "<h2 style='color: red;'>Database Error:</h2> " . $e->getMessage();
}
